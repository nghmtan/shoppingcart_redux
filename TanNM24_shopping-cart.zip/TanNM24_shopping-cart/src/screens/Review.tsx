import React from "react";
import construct from "../assets/images/comming-soon.png";
const Review = () => {
  return (
    <div className="construct">
      <img src={construct} alt="" />
    </div>
  );
};

export default Review;
